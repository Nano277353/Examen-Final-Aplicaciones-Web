<footer class="main-footer">
  <strong>Copyright &copy; 2025 <a href="#" target="_blank">CineClub</a>.</strong> All rights reserved.
  <div class="pull-right hidden-xs">
      <b>Version</b> Beta
  </div>
</footer>